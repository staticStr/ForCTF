<?php
error_reporting(0);
if(@!$_GET['order_by'])
	die('?order_by=1');

$conn = mysqli_connect('127.0.0.1','root','','anheng_sql');
$sql = 'select * from goods order by '.$_GET['order_by'];
//$sql = 'select * from goods order by if(substr((select flag from flag),1,1)="f",id,name)';

$res = mysqli_query($conn,$sql);
$array = mysqli_fetch_all($res);
echo 'id | name | price<br/>';
foreach($array as $line)
{
	echo($line[0].' '.$line[1].' '.$line[2].'<br/>');
}

?>